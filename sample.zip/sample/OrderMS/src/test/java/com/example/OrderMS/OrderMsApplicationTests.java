package com.example.OrderMS;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
