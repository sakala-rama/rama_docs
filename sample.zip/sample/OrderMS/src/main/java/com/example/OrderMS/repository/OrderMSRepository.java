package com.example.OrderMS.repository;

public class OrderMSRepository {

}
