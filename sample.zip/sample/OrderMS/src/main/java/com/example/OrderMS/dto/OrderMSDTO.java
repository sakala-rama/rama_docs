package com.example.OrderMS.dto;

public class OrderMSDTO {

}
