package com.example.OrderMS.entity;

import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;


@Entity
public class orderdetails {
	
	@Id
	@Column(name="ORDERID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer orderId;
	
	@Column(name="BUYERID")
	Integer buyerid;
	
	@Column(name="AMOUNT")
	Double amount;
	
	@Column(name="DATE")
	LocalDate date;
	
	@Column(name="ADDRESS")
	String address;
	
	@Column(name="STATUS")
	String status; 
	
	
	public orderdetails() {
		super();
	}
	
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(Integer buyerid) {
		this.buyerid = buyerid;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
