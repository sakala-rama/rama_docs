package com.example.OrderMS.service;

public class OrderMSService {

}
